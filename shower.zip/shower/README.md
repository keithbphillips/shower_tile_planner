# Shower tile planner

A single-page tool for laying out wall tile in a shower. Enter up to four
wall sizes, your tile size, grout joint, edge gap, and floor buildup, and it
draws each wall to scale with full and cut tiles, shows the ledger board
height, and lists end cuts and cut rows for every wall.

## Use

Open `index.html` in any browser. No build step or server needed. Settings
are saved in the browser, so they're still there next time you open it.

Sizes accept fractions (`70 1/2`, `70-1/2`, `9/16`) or decimals (`70.5`).

## How it lays out tile

- **Width:** tries both centering a tile and centering a grout joint on each
  wall, and keeps whichever leaves larger end pieces.
- **Balanced cuts:** one less full row, with equal cut rows at the floor and
  ceiling.
- **Full row at floor:** full rows from the finished floor up, with a cut
  strip at the ceiling.
- **1/3 offset:** each course shifts one third of a tile length.
- **Ledger:** height of the ledger's top edge above the pan (mud bed), which
  is where the first row above the bottom cut row starts. Floor buildup is
  the floor tile plus thinset.

Measure side walls from the face of the back wall tile.
